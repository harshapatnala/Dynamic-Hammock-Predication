#include "pipeline.h"


pipeline_register::pipeline_register() {
	valid = false;
}
