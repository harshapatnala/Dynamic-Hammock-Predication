require_fp;
WRITE_RD(sext32(FRS1));
