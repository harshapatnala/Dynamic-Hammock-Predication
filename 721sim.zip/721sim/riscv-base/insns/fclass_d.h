require_fp;
WRITE_RD(f64_classify(FRS1));
