if(cmp_trunc(RS1) != cmp_trunc(RS2))
  set_pc(BRANCH_TARGET);
