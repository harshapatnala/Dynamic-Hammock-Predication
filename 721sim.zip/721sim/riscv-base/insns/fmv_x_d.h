require_xpr64;
require_fp;
WRITE_RD(FRS1);
