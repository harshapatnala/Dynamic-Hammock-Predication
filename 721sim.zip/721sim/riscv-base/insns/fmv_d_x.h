require_xpr64;
require_fp;
WRITE_FRD(RS1);
