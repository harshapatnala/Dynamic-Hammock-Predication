WRITE_RD(MMU.load_int32(RS1 + insn.i_imm()));
