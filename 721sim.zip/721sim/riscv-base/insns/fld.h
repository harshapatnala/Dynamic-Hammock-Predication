require_fp;
WRITE_FRD(MMU.load_int64(RS1 + insn.i_imm()));
