require_fp;
softfloat_roundingMode = RM;
WRITE_FRD(f32_to_f64(FRS1));
set_fp_exceptions;
