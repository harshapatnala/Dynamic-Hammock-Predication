WRITE_RD(MMU.load_uint16(RS1 + insn.i_imm()));
