require_fp;
WRITE_RD(f32_classify(FRS1));
