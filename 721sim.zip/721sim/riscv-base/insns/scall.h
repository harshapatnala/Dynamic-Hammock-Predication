throw trap_syscall();
