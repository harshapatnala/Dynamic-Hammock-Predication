require_fp;
WRITE_FRD(RS1);
