require_fp;
WRITE_FRD(MMU.load_int32(RS1 + insn.i_imm()));
