WRITE_RD(cmp_trunc(RS1) < cmp_trunc(insn.i_imm()));
