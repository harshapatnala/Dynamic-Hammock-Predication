WRITE_RD(sreg_t(cmp_trunc(RS1)) < sreg_t(cmp_trunc(insn.i_imm())));
