require_fp;
WRITE_RD(f32_le(FRS1, FRS2));
set_fp_exceptions;
